﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.Utility
{
    public static class Globals
    {
        public const int Seed = 1;
        public const int Height = 10;
        public const int Width = 10;
        public const int NumbeOfPoints = 5;

        public const int RoundVal = 5;
    }
}
